var express= require('express');
var mysql= require('mysql');
var app=express();
var connection= mysql.createConnection({
    host: 'localhost',
    user:'root',
    password:'',
    database:'login'
});
connection.connect(function(error){
    if(!!error){
        console.log('Error');
    } else{
        console.log('Connected');
    }
}); 
app.get('/', function(req,resp){
    connection.query("Select * from details", function(error,rows,fields)
     if(!!error){
         console.log("error in query");
     }
     else{
         console.log('success')
     }
    )
})
app.listen(1337);